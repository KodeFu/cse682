//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TestFramework.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TESTFRAMEWORK_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       130
#define IDC_BUTTON_BROWSE               1000
#define IDC_BUTTON_RUNTESTS             1002
#define IDC_LIST_TESTS                  1004
#define IDC_BUTTON_RESET                1005
#define IDC_LIST2                       1006
#define IDC_BUTTON_RESETLOG             1007
#define IDC_BUTTON_EXPORT               1008
#define ID_FILE_EDIT                    32771
#define ID_FILE_QUIT                    32772
#define ID_HELP_ABOUT                   32773
#define ID_FILE_OPENTESTS               32774
#define ID_EDIT_RESETTESTLIST           32775
#define ID_EDIT_RESETLOG                32776
#define ID_FILE_EXPORTLOG               32777
#define ID_EDIT_RUNTESTS                32778
#define IDC_RBUTTON5                    32780
#define IDC_RBUTTON10                   32781
#define IDC_RBUTTON15                   32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
